package com.example.demo.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;
import com.example.demo.repository.GameRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import com.example.demo.model.Game;
import com.example.demo.model.Review;

public class ReviewFrontController {
	@Autowired
	private GameRepository repository;
	@RequestMapping(value = "/games/{id}")
	public String displayProductByUrl(@PathVariable("id") long id, Model model) {
	 
	Optional<Game> game = repository.findById(id);
	model.addAttribute("game",game);
	Review newReview = new Review();
	/*newReview.setGame(game);*/
	model.addAttribute("review",newReview);
	return "game";
	}

}
