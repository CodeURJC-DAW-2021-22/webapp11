package com.example.demo.repository;

import com.example.demo.model.Game;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameRepository extends JpaRepository<Game, Long> {


    public Page<Game> findAll(Pageable page);
}

