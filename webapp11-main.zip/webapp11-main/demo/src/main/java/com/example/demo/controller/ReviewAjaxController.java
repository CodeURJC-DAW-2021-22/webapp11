package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Review;
import com.example.demo.service.ReviewService;

public class ReviewAjaxController {

	
	
	@Controller
	public class AjaxFrontController {
	 
	 
	    @Autowired
	     private ReviewService reviewService;
	 
	    @RequestMapping(value = "/createReview",method = RequestMethod.POST/*, consumes = {"application/json;charset=utf-8"}*/)
	    public @ResponseBody String getTranslitURL(Review review) {
	        System.out.println("*");
	        System.out.println("request is "+review.toString());
	        System.out.println("*");
	        String errorMessage="";
	        if(review.getName()==null || review.getName().equals("")){
	            errorMessage+="User name is required! ";
	        }
	        if(errorMessage.equals("")){
	            reviewService.save(review);
	            return "SUCCESS";
	        }else{
	            return errorMessage;
	        }
	    }
	}
	
	
	
}
