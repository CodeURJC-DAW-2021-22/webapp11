package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
@Table(name = "review")
public class Review {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private Long id;    
 
    @Column(name = "name", nullable = false, length = 100)
    private String name;
 
    @Column(name = "comment", nullable = false, length = 1000)
    private String comment;
 
 
    @ManyToOne
    @JoinColumn(name = "game", nullable = false)
    private Game game;
 
    
 
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

    public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	

	@Override
	public String toString() {
		return "Review [id=" + id + ", name=" + name + ", comment=" + comment + "]";
	}

	
 
}