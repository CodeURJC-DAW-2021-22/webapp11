# webapp11 
## Phase 0
***
### Entities
**User:**
*Anonimus:*  This user visits the web without introducing any type of credential. He can search through the web but he can not buy, sell, or write any comments on the forums.

*Client:* This user introduces his credentials to access the website. He has personal data stored in the web such as his name, his avatar, a list of every item he´s bought or sold. He can also post comments and edit them at any given time. This user has acces to all of his personal information and can change or errase it at any point.

*Admin:* This user has total control over the website. He is able to change the prices of any item as well as the availability of them. He is also able to errase any comments that disregards the web policy. 
***
**Games:** They are the physical object being sold or bought within the aplication. They are divided in diferent categories depending on what type of game it is and if it´s made for PC or console.
***
**Comment:** Every game will have a section where any user that is register can post a comment. They can be opinions about the game or questions that can be answered by the admin user or by other costumers.
***
### Images
Every game will have a picture of the boxart on the website so that the costumers can identify them. The clients will have an avatar to represent them when they post comments.
***
### Graphics
Every game will have a bar graphic that represents how good people think it is. Every graphic will be divided into 5 diferent bars. Ranging from 5 stars to 1 star, 5 being the best and 1 being the worst.
***
### Complementary Tecnology
Every costumer will recieve an email of confirmation every time he buys or sells a game.
***
### Algorythm
The website will recomend the users the game based on what game they bought, sold, liked or commented on. Assuming these actions will be performed on game that the user has an interest in.

***
## Phase 2

### Diagram of the app


![diagrama app](https://user-images.githubusercontent.com/49288214/154924842-e50ac283-3d4a-43e7-b173-23ba09a78c9e.jpg)

